function transfer() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tablink = tabs[0].url;
        document.getElementById("p1").textContent = "The URL being tested is - " + tablink;

        var xhr = new XMLHttpRequest();
        var params = "url=" + encodeURIComponent(tablink);
        var markup = "url=" + encodeURIComponent(tablink) + "&html=" + encodeURIComponent(document.documentElement.innerHTML);
        xhr.open("POST", "http://localhost:8000/clientServer.php", false);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(markup);
        document.getElementById("div1").textContent = xhr.responseText;
        return xhr.responseText;
    });
}

document.addEventListener("DOMContentLoaded", function () {
    var button = document.getElementById("button1");
    if (button) {
        button.addEventListener("click", function () {
            var val = transfer();
        });
    } else {
        console.error("Button element not found.");
    }

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tablink = tabs[0].url;
        var p1 = document.getElementById("p1");
        if (p1) {
            p1.textContent = "The URL being tested is - " + tablink;
        } else {
            console.error("p1 element not found.");
        }
    });
});

